﻿using GruberEats.Menu_and_Products;
using System;
using System.Collections.Generic;

namespace GruberEats
{
    class MainPanel
    {
        static void Main(string[] args)
        {
            Database Gruber = new Database();
            Restaurant U_Joli = new Restaurant("U Joli", 35m, 14.5m, new Menu());
            U_Joli.Menu.AddProducts(new List<Product>
            {   new Food("Pierogi", 21.5m, CousineStyle.Polish),
                new Food("Naleśniki", 15m, CousineStyle.Polish),
                new Food("Gołąbki", 18m, CousineStyle.Polish),
                new Food("Żurek", 12m, CousineStyle.Polish),
                new Food("Pomidorowa", 10m, CousineStyle.Polish),
                new Food("Rosół", 10m, CousineStyle.Polish),
                new Drink("Woda", 6m, CousineStyle.Ordinary),
                new Drink("Herbata", 8m, CousineStyle.Ordinary),
                new Drink("Piwo", 8m, CousineStyle.Ordinary),
                new Drink("Kompot", 9m, CousineStyle.Polish),
                new Drink("Nalewka", 6m, CousineStyle.Polish)});

            Restaurant Nova = new Restaurant("Nova", 70m, 18.5m, new Menu());
            Nova.Menu.AddProducts(new List<Product>
            {   new Food("Tortilla", 20m, CousineStyle.Mexican),
                new Food("Nachos", 14m, CousineStyle.Mexican),
                new Food("Enchilada", 16m, CousineStyle.Mexican),
                new Food("Carbonara", 15m, CousineStyle.Italian),
                new Food("Pizza", 12m, CousineStyle.Italian),
                new Food("Lasagne", 10m, CousineStyle.Italian),
                new Drink("Woda", 6m, CousineStyle.Ordinary),
                new Drink("Herbata", 8m, CousineStyle.Ordinary),
                new Drink("Piwo", 8m, CousineStyle.Ordinary),
                new Drink("Latte", 6m, CousineStyle.Italian),
                new Drink("Espresso", 8m, CousineStyle.Italian),
                new Drink("Margarita", 13m, CousineStyle.Mexican),
                new Drink("Cerveza", 9m, CousineStyle.Mexican)});

            Gruber.AddRestaurant(U_Joli);
            Gruber.AddRestaurant(Nova);
            Gruber.AddDeliverer(new Deliverer("Vikas", Deliverer.VehicleType.Bike));
            Gruber.AddDeliverer(new Deliverer("Jacek", Deliverer.VehicleType.Scooter));
            Gruber.AddDeliverer(new Deliverer("Rahim", Deliverer.VehicleType.Scooter));
            Gruber.AddCustomer(new Customer("Nikodem Cabała", "Warszawa"));
            Gruber.AddCustomer(new Customer("Jan Nowak", "Warszawa"));

            Gruber.MakeAnOrder(0, 0, Deliverer.VehicleType.Bike, new List<int> { 0, 2, 50 }, 5, 5);
            Gruber.MakeAnOrder(1, 1, Deliverer.VehicleType.Bike, new List<int> { 1, 2, 3 }, 3, 5);
            Gruber.MakeAnOrder(1, 1, Deliverer.VehicleType.Bike, new List<int> { 0, 3, 4 }, 2, 1);
            Gruber.MakeAnOrder(1, 1, Deliverer.VehicleType.Scooter, new List<int> { 1, 2, 4 }, 2, 2);
            Gruber.MakeAnOrder(0, 1, 1, Deliverer.VehicleType.Bike, new List<int> { 0, 2, 3 }, new List<int> { 0, 2, 3 }, 4, 5, 5);
            Gruber.MakeAnOrder(0, 1, 1, Deliverer.VehicleType.Scooter, new List<int> { 1, 3, 5 }, new List<int> { 1, 3, 4 }, 2, 3, 4);

            Console.WriteLine(Gruber.GetRestaurantsList[1].GetCousineStyle());
            Gruber.GetOrdersDeliveredBy(0);
            Gruber.GetOrderById(3);

            //wyrzuca wszystkie zamówienia w konsoli więc robi się bałagan, ale polecam odpalić 
           // Gruber.GetAllOrders();



        }
    }
}
