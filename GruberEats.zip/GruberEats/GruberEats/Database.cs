﻿using GruberEats.Menu_and_Products;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GruberEats
{
    public class Database
    {
        private List<Customer> CustomersList { get; set; } = new List<Customer>();
        private List<Deliverer> DeliverersList { get; set; } = new List<Deliverer>();
        private List<Restaurant> RestaurantsList { get; set; } = new List<Restaurant>();
        private List<Order> OrdersList { get; set; } = new List<Order>();

        public ReadOnlyCollection<Customer> GetCustomersList
            => CustomersList.AsReadOnly();
        public ReadOnlyCollection<Deliverer> GetDeliverersList
            => DeliverersList.AsReadOnly();
        public ReadOnlyCollection<Restaurant> GetRestaurantsList
            => RestaurantsList.AsReadOnly();
        public ReadOnlyCollection<Order> GetOrdersList
            => OrdersList.AsReadOnly();


        public Database()
        {
            CustomersList = new List<Customer>();
            DeliverersList = new List<Deliverer>();
            RestaurantsList = new List<Restaurant>();
            OrdersList = new List<Order>();
        }

        public void AddDeliverer(Deliverer deliverer)
        {
            DeliverersList.Add(deliverer);
        }
        public void AddCustomer(Customer customer)
        {
            CustomersList.Add(customer);
        }
        public void AddRestaurant(Restaurant restaurant)
        {
            RestaurantsList.Add(restaurant);

        }

        public void MakeAnOrder(int restaurantID, int customerID, Deliverer.VehicleType vehicle, List<int> menuItems, int delivererRating, int restaurantRating)
        {
            Restaurant restaurant = RestaurantsList[restaurantID];
            Customer customer = CustomersList[customerID];
            Deliverer deliverer = FindByVehicle(vehicle);
            List<Product> products = GenerateProductList(restaurant, menuItems);
            Order order = Order.MakeSingleOrder(restaurant, customer, deliverer, products, OrdersList.Count + 1, delivererRating,restaurantRating);
            OrdersList.Add(order);
        }
        public void MakeAnOrder(int restaurant1ID, int restaurant2ID, int customerID, Deliverer.VehicleType vehicle, List<int> restaurant1MenuItems, List<int> restaurant2MenuItems, int delivererRating, int restaurant1Rating, int restaurant2Rating)
        {
            Restaurant restaurant1 = RestaurantsList[restaurant1ID];
            Restaurant restaurant2 = RestaurantsList[restaurant2ID];
            Customer customer = CustomersList[customerID];
            Deliverer deliverer = FindByVehicle(vehicle);
            List<Product> products1 = GenerateProductList(restaurant1, restaurant1MenuItems);
            List<Product> products2 = GenerateProductList(restaurant2, restaurant2MenuItems);
            Order order = Order.MakeDoubleOrder(restaurant1, restaurant2, customer, deliverer, products1, products2, OrdersList.Count + 1, delivererRating,restaurant1Rating,restaurant2Rating);
            OrdersList.Add(order);
          }

        private Deliverer FindByVehicle(Deliverer.VehicleType vehicle)
        {
            Deliverer deliverer = null;
            for (int i = 0; i < DeliverersList.Count; i++)
            {
                if (DeliverersList[i].Vehicle == vehicle)
                {
                    deliverer = DeliverersList[i];
                    break;
                }
            }
            return deliverer;
        }

        private List<Product> GenerateProductList(Restaurant restaurant, List<int> menuItems)
        {
            List<Product> products = new List<Product>();
            for (int i = 0; i < menuItems.Count; i++)
            {
                try
                {
                    products.Add(restaurant.Menu.ProductList[menuItems[i]]);
                }
                catch
                {
                    Console.WriteLine("Nie ma takiej pozycji w menu");
                }
            }
            return products;
        }


        public void GetAllOrders()
        {
            for (int i = 0; i < OrdersList.Count; i++)
                Console.WriteLine(OrdersList[i].OrderInfo());  
        }

        public void GetOrderById(int ID)
        {
            for (int i = 0; i < OrdersList.Count; i++)
                if(OrdersList[i].OrderID==ID)
                    Console.WriteLine(OrdersList[i].OrderInfo());
        }

        public void GetOrdersDeliveredBy(int delivererID)
        {
            StringBuilder deliveries = new StringBuilder();
            deliveries.Append($"{DeliverersList[delivererID].Name} - rating {DeliverersList[delivererID].Rating}: ");
            for (int i = 0; i < OrdersList.Count; i++)
            {
                if (OrdersList[i].Deliverer == DeliverersList[delivererID])
                {
                    deliveries.Append($"Delivery {OrdersList[i].OrderID}");
                    if (!(i == OrdersList.Count - 1))
                        deliveries.Append(", ");
                }
            }
            Console.WriteLine(deliveries);
        }

    }
}
