﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GruberEats
{
    public class Customer
    {
        public string Name { get; private set; }
        public string Address { get; private set; }
        private Guid guid { get; set; }

        public Customer(string name, string address)
        {
            guid = Guid.NewGuid();
            Name = name;
            Address = address;
        }

        public override bool Equals(object obj)
        {
            return obj is Customer customer &&
                   Name == customer.Name &&
                   Address == customer.Address &&
                   guid.Equals(customer.guid);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name, Address, guid);
        }
    }
}
