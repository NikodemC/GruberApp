﻿using GruberEats.Menu_and_Products;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GruberEats
{
    public class Order
    {
        //może samo ID zamiast całych obiektów?
        public Restaurant Restaurant1 { get; private set; }
        public decimal Restaurant1Rating { get; private set; }
        public Restaurant Restaurant2 { get; private set; }
        public decimal Restaurant2Rating { get; private set; }
        public Customer Customer { get; private set; }
        public Deliverer Deliverer { get; private set; }
        public decimal DelivererRating { get; private set; }
        public DateTime OrderTime { get; private set; }
        public List<Product> OrderItems1 { get; private set; }
        public List<Product> OrderItems2 { get; private set; }
        public int OrderID { get; private set; }
        public bool IsDoubleOrder { get; private set; }

        public static Order MakeSingleOrder(Restaurant restaurant, Customer customer, Deliverer deliverer, List<Product> orderItems, int ID, int delivererRating, int restaurantRating)
                 => new Order(restaurant, customer, deliverer, orderItems, ID, delivererRating, restaurantRating);

        public static Order MakeDoubleOrder(Restaurant restaurant1, Restaurant restaurant2, Customer customer, Deliverer deliverer, List<Product> orderItems1, List<Product> orderItems2, int ID, int delivererRating, int restaurant1Rating, int restaurant2Rating)
                 => new Order(restaurant1, restaurant2, customer, deliverer, orderItems1, orderItems2, ID, delivererRating, restaurant1Rating, restaurant2Rating);

        private Order(Restaurant restaurant, Customer customer, Deliverer deliverer, List<Product> orderItems, int ID, int delivererRating, int restaurantRating)
        {
            Restaurant1 = restaurant;
            //Updates Restaurant overall Rating
            Restaurant1.AddRating(restaurantRating);
            //Saves Restaurant Rating value at the moment of this specific Order 
            Restaurant1Rating = Restaurant1.Rating;
            Customer = customer;
            Deliverer = deliverer;
            //Updates Deliverer overall Rating
            Deliverer.AddRating(delivererRating);
            //Saves Deliverer Rating value at the moment of this specific Order 
            DelivererRating = Deliverer.Rating;
            OrderItems1 = orderItems;
            OrderTime = DateTime.UtcNow;
            OrderID = ID;
            IsDoubleOrder = false;
        }

        private Order(Restaurant restaurant1, Restaurant restaurant2, Customer customer, Deliverer deliverer, List<Product> orderItems1, List<Product> orderItems2, int ID, int delivererRating, int restaurant1Rating, int restaurant2Rating)
        {
            Restaurant1 = restaurant1;
            Restaurant1.AddRating(restaurant1Rating);
            Restaurant1Rating = Restaurant1.Rating;
            Restaurant2 = restaurant2;
            Restaurant2.AddRating(restaurant2Rating);
            Restaurant2Rating = Restaurant2.Rating; ;
            Customer = customer;
            Deliverer = deliverer;
            Deliverer.AddRating(delivererRating);
            DelivererRating = Deliverer.Rating;
            OrderItems1 = orderItems1;
            OrderItems2 = orderItems2;
            OrderTime = DateTime.UtcNow;
            OrderID = ID;
            IsDoubleOrder = true;
        }


        private decimal CalculateOrderedProductsCost(Restaurant restaurant)
        {
            decimal orderValue = 0;
            if (restaurant == Restaurant1)
                for (int i = 0; i < OrderItems1.Count; i++)
                    orderValue += OrderItems1[i].Price;

            else
                for (int i = 0; i < OrderItems2.Count; i++)
                    orderValue += OrderItems2[i].Price;

            return orderValue;
        }

        private decimal CalculateDeliveryCost(Restaurant restaurant) => CalculateOrderedProductsCost(restaurant) > restaurant.FreeDeliveryStartingPrice ? 0m : restaurant.DeliveryCost;

        private decimal CalculateTotalOrderCost(Restaurant restaurant) => CalculateOrderedProductsCost(restaurant) + CalculateDeliveryCost(restaurant);

        private string PorductList()
        {
            StringBuilder productList = new StringBuilder();
            for (int i = 0; i < OrderItems1.Count; i++)
            {
                productList.Append($"{OrderItems1[i].Name} - {OrderItems1[i].Price} zł");
                if (!(i == OrderItems1.Count - 1))
                    productList.Append(", ");
            }
            if (IsDoubleOrder)
            {
                productList.Append(", ");
                for (int i = 0; i < OrderItems2.Count; i++)
                {
                    productList.Append($"{OrderItems2[i].Name} - {OrderItems2[i].Price} zł");
                    if (!(i == OrderItems2.Count - 1))
                        productList.Append(", ");
                }
            }
            return productList.ToString();
        }
        public string OrderInfo()
        {
            if (!IsDoubleOrder)
            {
                return $"****************************\nZamówienie nr: {OrderID}\nData zamówienia: {OrderTime}\nKlient: {Customer.Name}\nRestauracja: {Restaurant1.Name} - ocena {Restaurant1Rating.ToString("#.##")}\n" +
                    $"Zamówiono: {PorductList()}\nProdukty: {CalculateOrderedProductsCost(Restaurant1)} zł\nDostawa: {CalculateDeliveryCost(Restaurant1)} zł\n" +
                    $"Suma zamówienia: {CalculateTotalOrderCost(Restaurant1)} zł\nDostarczył: {Deliverer.Name} - ocena {DelivererRating.ToString("#.##")}";
            }
            else
                return $"****************************\nZamówienie nr: {OrderID}\nData zamówienia: {OrderTime}\nKlient: {Customer.Name}\n" +
                    $"Restauracje: {Restaurant1.Name} - ocena {Restaurant1Rating.ToString("#.##")}, {Restaurant2.Name} - ocena {Restaurant2Rating.ToString("#.##")}\nZamówiono: {PorductList()}\n" +
                    $"Produkty: {Restaurant1.Name} {CalculateOrderedProductsCost(Restaurant1)} zł + {Restaurant2.Name} {CalculateOrderedProductsCost(Restaurant2)} zł = " +
                    $"{CalculateOrderedProductsCost(Restaurant1) + CalculateOrderedProductsCost(Restaurant2)} zł\n" +
                    $"Dostawa: {Restaurant1.Name} {CalculateDeliveryCost(Restaurant1)} zł, {Restaurant2.Name} {CalculateDeliveryCost(Restaurant2)} zł = " +
                    $"{CalculateDeliveryCost(Restaurant1) + CalculateDeliveryCost(Restaurant2)} zł\n" +
                    $"Suma zamówienia: {CalculateTotalOrderCost(Restaurant1) + CalculateTotalOrderCost(Restaurant2)} zł\nDostarczył: {Deliverer.Name} - ocena {DelivererRating.ToString("#.##")}";
        }


    }
}
