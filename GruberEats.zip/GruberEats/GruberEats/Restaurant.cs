﻿using GruberEats.Menu_and_Products;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GruberEats
{
    public class Restaurant :IRating
    {
        public string Name { get; private set; }
        public decimal FreeDeliveryStartingPrice { get; private set; }
        public decimal DeliveryCost { get; private set; }
        private CousineStyle RestaurantStyle { get;  set; }
        public Menu Menu { get; private set; }
        private List<int> AllRatings { get; set; } = new List<int>();
        public decimal Rating{ get; private set; }
        private Guid guid { get; set; }

        public Restaurant(string name, decimal freeDeliveryStartingPrice, decimal deliveryCost, Menu menu)
        {
            guid = Guid.NewGuid();
            Name = name;
            FreeDeliveryStartingPrice = freeDeliveryStartingPrice;
            DeliveryCost = deliveryCost;
            Menu = menu;
            RestaurantStyle = Menu.GetCousineStyle();
            AllRatings = new List<int>();
            Rating = 0m;
        }

        public CousineStyle GetCousineStyle() 
            => RestaurantStyle = Menu.GetCousineStyle();

        public void AddRating(int rating)
        {
            AllRatings.Add(rating);
            decimal ratings = 0;
            for (int i = 0; i < AllRatings.Count; i++)
            {
                ratings += AllRatings[i];
            }
            Rating = ratings / AllRatings.Count;
        }

        public override bool Equals(object obj)
        {
            return obj is Restaurant restaurant &&
                   Name == restaurant.Name &&
                   FreeDeliveryStartingPrice == restaurant.FreeDeliveryStartingPrice &&
                   DeliveryCost == restaurant.DeliveryCost &&
                   RestaurantStyle == restaurant.RestaurantStyle &&
                   EqualityComparer<Menu>.Default.Equals(Menu, restaurant.Menu) &&
                   EqualityComparer<List<int>>.Default.Equals(AllRatings, restaurant.AllRatings) &&
                   Rating == restaurant.Rating &&
                   guid.Equals(restaurant.guid);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name, FreeDeliveryStartingPrice, DeliveryCost, RestaurantStyle, Menu, AllRatings, Rating, guid);
        }
    }
}
