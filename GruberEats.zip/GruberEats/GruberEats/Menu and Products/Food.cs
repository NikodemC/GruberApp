﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GruberEats.Menu_and_Products
{
    public class Food : Product
    {
        public Food(string name, decimal price, CousineStyle cousineStyle) : base(name, price, cousineStyle)
        {
        }

        public override bool Equals(object obj)
        {
            return base.Equals(obj);
        }

        public override int GetHashCode()
        {
            return base.GetHashCode();
        }

        public override string ToString()
        {
            return base.ToString();
        }
    }
}
