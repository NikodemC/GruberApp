﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GruberEats.Menu_and_Products
{
    abstract public class Product
    {
        public string Name { get; private set; }
        public decimal Price { get; private set; }
        public CousineStyle Style { get; private set; }

        public Product(string name, decimal price, CousineStyle cousineStyle)
        {
            Name = name;
            Price = price;
            Style = cousineStyle;
        }

        public override bool Equals(object obj)
        {
            return obj is Product product &&
                   Name == product.Name &&
                   Price == product.Price &&
                   Style == product.Style;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name, Price, Style);
        }

        public override string ToString()
        {
            return $"{Name} {Price} zł";
        }
    }
}
