﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GruberEats.Menu_and_Products
{
    public class Menu
    {
        public List<Product> ProductList { get; private set; }
        private CousineStyle CousineStyle {  get;  set; }
        public Menu()
        {
            ProductList = new List<Product>();
            CousineStyle = CousineStyle.Ordinary;
        }

        public void AddSingleProduct(Product product)
        {
            if (ProductList.Count == 0)
            {
                ProductList.Add(product);
            }
            else if (!ProductList.Contains(product))
                ProductList.Add(product);
        }

        public void AddProducts(List <Product> products)
        {
            for (int i = 0; i < products.Count; i++)
                AddSingleProduct(products[i]);
        }
        public void RemoveProduct(int position)
        {
            if(position!=null & position >= 0)
            {
                ProductList.RemoveAt(position - 1);
            }
        }

        public CousineStyle GetCousineStyle()
        {
            //Set initial Style type to ordinary(basic) and then check all the items in the menu and expand the Style accordingly (secure in case a product was removed from the menu)
            CousineStyle = CousineStyle.Ordinary;
            for(int i = 0; i < ProductList.Count; i++)
            {
                if(!(ProductList[i].Style==CousineStyle))
                {
                    CousineStyle = CousineStyle | ProductList[i].Style;
                }
            }
            return CousineStyle;
        }

        public override bool Equals(object obj)
        {
            return obj is Menu menu &&
                   EqualityComparer<List<Product>>.Default.Equals(ProductList, menu.ProductList) &&
                   CousineStyle == menu.CousineStyle;
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(ProductList, CousineStyle);
        }
    }
}
