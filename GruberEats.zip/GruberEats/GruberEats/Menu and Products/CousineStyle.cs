﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GruberEats
{
    [Flags]
    public enum CousineStyle
    {
            Ordinary = 1 << 0,
            Italian = 1 << 1,
            Mexican = 1 << 2,
            Polish = 1 << 3
    }
}
