﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace GruberEats
{
    public class Deliverer :IRating
    {
        public string Name { get; private set; }
        public VehicleType Vehicle { get; private set; }
        private List<int> AllRatings { get; set; }
        public decimal Rating { get; private set; }
        private Guid guid { get; set; }

        public enum VehicleType
        {
            Bike = 1,
            Scooter = 2,
        }

        public Deliverer(string name, VehicleType vehicleType)
        {
            guid = Guid.NewGuid();
            Name = name;
            Vehicle = vehicleType;
            AllRatings = new List<int>();
            Rating = 0m;
        }

        public void AddRating(int rating)
        {
            AllRatings.Add(rating);
            decimal ratings = 0;
            for(int i=0; i < AllRatings.Count; i++)
            {
                ratings += AllRatings[i];
            }
            Rating = ratings / AllRatings.Count;
        }

        public override bool Equals(object obj)
        {
            return obj is Deliverer deliverer &&
                   Name == deliverer.Name &&
                   Vehicle == deliverer.Vehicle &&
                   EqualityComparer<List<int>>.Default.Equals(AllRatings, deliverer.AllRatings) &&
                   Rating == deliverer.Rating &&
                   guid.Equals(deliverer.guid);
        }

        public override int GetHashCode()
        {
            return HashCode.Combine(Name, Vehicle, AllRatings, Rating, guid);
        }
    }
}
