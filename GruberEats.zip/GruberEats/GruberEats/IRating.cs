﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GruberEats
{
    public interface IRating
    {
        decimal Rating { get; }
        void AddRating(int rating);
    }
}
